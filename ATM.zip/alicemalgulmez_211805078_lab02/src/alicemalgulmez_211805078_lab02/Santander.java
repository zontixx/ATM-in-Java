package alicemalgulmez_211805078_lab02;

import java.util.Scanner;
 public class Santander {
   private int id;
   private static double balance;
   public Santander() { }
   public Santander(int id) {
       this.id = id;
       Santander.balance = 100;
   }

   public void sBalance(double nBalance) {
       balance = nBalance;
   }

   public void sID(int nID) {
       id = nID;
   }

   public double gBalance() {
       return balance;
   }

   public int gID() {
       return id;
   }

   public double withDrawing(double withDrawAmount) {
       return balance = balance - withDrawAmount;
   }

   public double depositing(double depositAmount) {
       return balance = balance + depositAmount;
   }

   public static void main(String[] args) {

      Santander[] account = new Santander[10];
      for (int i = 0; i < account.length; i++) {
         account[i] = new Santander(i);
      }
      Scanner input = new Scanner(System.in);
      System.out.print("Welcome to Santander Bank ATM Services! Every transaction you make is protected and controlled by our security units.\n");
      System.out.print("Please enter your Bank ID to continue: ");
      int enteredID;
      do {
         enteredID = input.nextInt();
         if (enteredID <= 9 && enteredID >=0 && enteredID == account[enteredID].gID()) {
             do {
            	 System.out.println("Main Menu");
                 System.out.println("Language : English");
                 System.out.println("Press 1 for checking balance.");
                 System.out.println("Press 2 for withdrawing amount of money from your bank account.");
                 System.out.println("Press 3 for depositing amount of money from your bank account.");
                 System.out.println("Press 4 for exiting safely from our services.");
                System.out.print("Please enter your choice for the process that you want. Available options are indicated in the main menu:");
                int choice = input.nextInt();
                input.nextLine();
                 if (choice == 1) {
                    System.out.println("Your balance is: " + account[enteredID].gBalance());
                 } else if (choice == 2) {
                     System.out.print("Please enter the amount that you want to withdraw:");
                     int withdrawAmount = input.nextInt();
                     if (withdrawAmount <= balance) {
                    	 account[enteredID].withDrawing(withdrawAmount);
                     }
                     else {
                    	 System.out.print("Since the withdrawal amount is too large, we cannot fulfill this transaction. We are redirecting you to deposit menu.\n");
                    	 System.out.print("Please enter the amount that you want to deposit:");
                         int depositAmount = input.nextInt();
                         account[enteredID].depositing(depositAmount);
                     }
                 } else if (choice == 3) {
                     System.out.print("Please enter the amount that you want to deposit:");
                     int depositAmount = input.nextInt();
                     account[enteredID].depositing(depositAmount);
                 } else if (choice == 4) {
                	 System.out.println("All your transactions have been carried out successfully. Thank you for using Santander services and have a nice day!");
                     System.out.println("Exiting...");
                     System.out.println("Santander Bank is a part of the Santander Group (1857-2022). All rights reserved.");
                     System.out.println("Enter your Bank ID to continue. Forgot your Bank ID? Santander's Customer Services are 7/24 here for you! Contact number: +1 877 768 2265");
                     break;
                 }
              } while (true);
           }
           else{
               System.out.print("Please enter a valid Bank ID number!");
           }

       }while(true);
   }
}